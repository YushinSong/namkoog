import game_framework
import main_game
import test_collision

game_framework.run(main_game)