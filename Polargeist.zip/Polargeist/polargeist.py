import random
from pico2d import *

back = None
ground = None
sliding = True
running = True
jump = False
Go = False

#게임 오브젝트 클래스의 정의
class BackGround:
    def __init__(self):
        self.x = 550
        self.image = load_image('Ground\\background2.png')
        self.blue = load_image('Ground\\background_blue.png')
    def update(self):
        global Go
        if Go == True:
            self.x -= 2
            if self.x < -550:
                self.x = 550
    def draw(self):
        self.blue.clip_draw(0, 0, 512, 512, 550, 500, 1100, 1100)
        self.image.clip_draw(0, 0, 1536, 512, self.x, 500, 3300, 1100)

class Ground:
    def __init__(self):
        self.x = 900
        self.image = load_image('Ground\\ground2.png')
        self.line = load_image('Ground\\line.png')
        self.blue = load_image('Ground\\ground_blue.png')
    def update(self):
        global Go
        if Go == True:
            self.x -= 10
            if self.x < 400:
                self.x = 900
    def draw(self):
        self.blue.clip_draw(0, 0, 896, 127, 900, 70, 1800, 200)
        self.image.clip_draw(0, 0, 896, 127, self.x, 70, 1800, 200)
        self.line.clip_draw(0, 0, 896, 127, 560, 168, 900, 4)

class Change:
    def __init__(self):
         self.x, self.y = 1300, 390
         self.frame, self.count, self.round_count = 0, 0, 0
         # frame = 0, 6, 12, 18
         self.image = load_image('Item\\change.png')
    def update(self):
         global Go
         if Go == True:
            self.x -= 10
            if self.x < 0:
                self.x = 1300

    def back_draw(self):
         self.image.clip_draw(300, 0, 150, 300, self.x-20, self.y, 75, 150)
    def draw(self):
         self.image.clip_draw(0, 0, 150, 300, self.x, self.y, 75, 150)


class Airplane:
    def __init__(self):
        self.x, self.y = 100, 215
        self.frame = 0
        self.image = load_image('Character\\airplane.png')
    def update(self):
        self.frame = (self.frame + 1) % 6
    def draw(self):
        self.image.clip_draw(self.frame * 500, 0, 500, 500, self.x, self.y, 90, 90)

class Soldier:
    global sliding, move
    def __init__(self):
        self.x, self.y = 0, 215
        self.frame, self.count, self.round_count = 0, 0, 0
        # frame = 0, 6, 12, 18
        self.image = load_image('Character\\soldier76.png')
    def jump(self):
        global jump
        if jump == True:
            if (self.round_count < 2):
                if (self.round_count == 1):
                    self.frame = (self.frame + 1) % 46
                    self.round_count = 0
                self.round_count += 1
            if (self.count < 15):
                self.y += 12
                self.count += 1
            elif (self.count < 31):
                self.y -= 12
                self.count += 1
                if (self.count == 30):
                    self.count = 0
                    jump = False
        else:
            if (0 <= self.frame <= 5 or 41 <= self.frame <= 45):
                self.frame = 0
            elif (6 <= self.frame <= 15):
                self.frame = 10
            elif (16 <= self.frame <= 28):
                self.frame = 22
            elif (29 <= self.frame <= 40):
                self.frame = 34
    def update(self):
        global Go
        if Go == False:
            self.x += 10
            if self.x > 370:
                Go = True
        self.jump()
    def draw(self):
        self.image.clip_draw(self.frame*100, 0, 100, 100, self.x, self.y, 90, 90)

# 초기화 코드
def enter():
    global ground, soldier, back, airplane, change1
    open_canvas(1100, 600)
    back = BackGround()
    ground = Ground()
    soldier = Soldier()
    change1 = Change()
    airplane = Airplane()

#입력 핸들
def handle_events():
    global running
    global jump
    events = get_events()
    for event in events:
        if event.type == SDL_QUIT:
            running = False
        elif event.type == SDL_KEYDOWN and event.key == SDLK_ESCAPE:
            running = False
        if event.type == SDL_MOUSEBUTTONDOWN:
            jump = True

#게임 루프 코드
enter()
while running:
    handle_events()

    clear_canvas()

    soldier.update()
    ground.update()
    back.update()
    change1.update()
    #airplane.update()

    back.draw()
    ground.draw()
    change1.back_draw()
    soldier.draw()
    change1.draw()
    #airplane.draw()
    update_canvas()

    delay(0.013)
exit()

#종료 코드
